export const DB_HOST='localhost';
export const DB_USER='root';
export const DB_PASSWORD='Bhau2000#';
export const DB_NAME='bike_service_center';
export const TABLE_NAME='users';
export const SERVICE_CENTER_TABLE_NAME='service_center';
export const SERVICE_CENTER_BOOKING='bookings';

// export const ADMIN_TABLE_NAME='admin'
